import json
import RPi.GPIO as GPIO
from adxl345 import ADXL345
import smbus
import time
import telnetlib
import socket

GPIO.setmode(GPIO.BCM)

HOST = "192.168.43.120"
PORT = 7777
ID = 2
Trig = 23
Echo = 24
pin_input = 18

adxl345 = ADXL345()

GPIO.setup(Trig,GPIO.OUT)
GPIO.setup(Echo,GPIO.IN)

GPIO.output(Trig, False)

adxl345 = ADXL345()

bus = smbus.SMBus(1)

def to_json(data) :
    h_json = '{"type" : "request", "request" : "publish", "peripheral" : 2, "data" : "'+str(data)+'"}'
    parsed = json.loads(h_json)
    print(parsed)
    return json.dumps(parsed, indent = 4)

def get_luminosity (pin_input):
    count = 0
    MAX = 5000
    #Set up the pin as output to set it low
    GPIO.setup(pin_input, GPIO.OUT)
    GPIO.output(pin_input, GPIO.LOW)
    time.sleep(0.1)

    #Change the pin back to input and count until the pin goes high
    GPIO.setup(pin_input, GPIO.IN)
    while (GPIO.input(pin_input) != GPIO.HIGH):
        if count>=MAX:
            break
        count+=1

    #Return the value (not really accurate)
    return count

tn = telnetlib.Telnet(HOST,PORT)
_connect = '{"type" : "request", "request" : "connect", "peripheral" : '+str(ID)+'}'
parsed = json.loads(_connect)
print(parsed)
tn.write(json.dumps(parsed, indent = 4).encode("ascii"))
time.sleep(1)

_json  = json.dumps({'type' :'request', 'request' : 'publish', 'peripheral' :  0, 'data' : '0.5'})
_json = json.loads(_json)
frequencestr = _json["data"]
frequence = float(frequencestr)


bus.write_byte_data(0x68, 0x3E, 0x01)
bus.write_byte_data(0x68, 0x16, 0x18)

while True:
    time.sleep(float(frequence))
    
    GPIO.output(Trig,True)
    time.sleep(0.01)
    GPIO.output(Trig,False)
    while GPIO.input(Echo)==0:
        start = time.time()
    
    while GPIO.input(Echo)==1:
        end = time.time()
    
    distance = round((end-start) *343*100/2)    #343m/s is the sound speed, *100 to get it in cm, /2 because the signal is going there and coming back 

    time.sleep(frequence)
    axes = adxl345.getAxes(True)

    time.sleep(0.01)
    axes2 = adxl345.getAxes(True)

    x = axes2['x']-axes['x']
    y = axes2['y']-axes['y']
    z = axes2['z']-axes['z']

    print(" ------- ACCELERATION----------")
    print("Acceleration X :" + repr(x) + "g")
    print("Acceleration Y :" + repr(y) + "g")
    print("Acceleration Z :" + repr(z) + "g")
    print("\n")

    data = bus.read_i2c_block_data(0x68, 0x1D, 6)

    xGyro = data[0] * 256 + data[1]
    if xGyro > 32767 :
        xGyro -= 65536

    yGyro = data[2] * 256 + data[3]
    if yGyro > 32767 :
        yGyro -= 65536

    zGyro = data[4] * 256 + data[5]
    if zGyro > 32767 :
        zGyro -= 65536

    print(" ------- ROTATION----------")
    print("X-Axis of Rotation : %d radians/s" %xGyro)
    print("Y-Axis of Rotation : %d radians/s" %yGyro)
    print("Z-Axis of Rotation : %d radians/s" %zGyro)
    print("\n")

    print(" ------- DISTANCE----------")
    if(distance<2000):
        print("La distance est de :", distance,"cm")

    else:
        print("Distance supérieur à 20 mètres")
    print("\n")

    print(" ------- LUMINOSITE----------")
    lumi = get_luminosity(pin_input)
    lumi = 100- (lumi/50)
    print("Pourcentage de lumière : " + repr(lumi) + "%")
    print("\n")
    
    

    to_send = '{"accelerometreX" : '+ repr(x) +',"accelerometreY" : ' + repr(y) + ',"accelerometreZ" : '+ repr(z) +', "gyroscopeX": '+ repr(xGyro)+',"gyroscopeX": '+repr(yGyro)+',"gyroscopeX": '+repr(zGyro)+', "SONAR" : '+repr(distance)+', "luminosite" : '+repr(lumi)+'}'  
    
    d_parsed = json.loads(to_send)
    json.dumps(d_parsed, indent = 4)
    _json = to_json(d_parsed)
    tn.write(_json.encode("ascii"))

    time.sleep(0.1)
   # print(tn.read_all())
         

GPIO.cleanup()
    
#https://tutorials-raspberrypi.com/raspberry-pi-ultrasonic-sensor-hc-sr04/ to get the tutorial
